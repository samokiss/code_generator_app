<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};
#end

/**
 * @author Samuel Gomis <gomis.samuel@external.openclassrooms.com>
 */
class ${NAME} {

}